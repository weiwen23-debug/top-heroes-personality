/** Top Heroes personality quiz — Google Apps Script backend.
 * Deploy as Web app: Execute as Me; Who has access: Anyone.
 * Create this script from Extensions > Apps Script inside your destination Google Sheet.
 */
const SHEET_NAME = 'Responses';
const HEADERS = ['Timestamp','In-game name','Primary personality','Secondary personality','Third personality','Blend JSON','Scores JSON','Answers JSON','Submission ID'];
function sheet_(){
  const ss=SpreadsheetApp.getActiveSpreadsheet();
  if(!ss) throw new Error('Please bind this script to a Google Sheet.');
  let sh=ss.getSheetByName(SHEET_NAME);
  if(!sh) sh=ss.insertSheet(SHEET_NAME);
  if(sh.getLastRow()===0){sh.appendRow(HEADERS);sh.setFrozenRows(1);}
  return sh;
}
function doPost(e){
  try{
    const data=JSON.parse((e.parameter&&e.parameter.payload)||'{}');
    if(data.action!=='submit') throw new Error('Unknown action');
    const name=String(data.name||'').trim().replace(/\s+/g,' ').slice(0,40);
    if(name.length<2) throw new Error('In-game name required');
    const answers=data.answers;
    if(!Array.isArray(answers)||answers.length!==18||answers.some(x=>!Number.isInteger(x)||x<0||x>5))throw new Error('Incomplete quiz');
    const id=String(data.submissionId||'').slice(0,100);
    const sh=sheet_();
    const lock=LockService.getScriptLock();lock.waitLock(10000);
    try{
      // Idempotency: repeated POSTs with the same submission ID are not double-counted.
      if(id&&sh.getLastRow()>1){const ids=sh.getRange(2,9,sh.getLastRow()-1,1).getValues().flat();if(ids.includes(id))return ContentService.createTextOutput('OK');}
      const safe=s=>{const v=String(s||'');return /^[=+\-@\t\r]/.test(v)?"'"+v:v};
      sh.appendRow([new Date(),safe(name),safe(data.primary),safe(data.secondary),safe(data.tertiary),JSON.stringify(data.blend||[]),JSON.stringify(data.scores||{}),JSON.stringify(answers),id]);
    }finally{lock.releaseLock()}
    return ContentService.createTextOutput('OK');
  }catch(err){return ContentService.createTextOutput('ERROR: '+err.message)}
}
function doGet(e){
  const callback=String((e.parameter&&e.parameter.callback)||'');
  let response;
  try{
    if((e.parameter&&e.parameter.action)!=='stats')throw new Error('Unknown action');
    const sh=sheet_();const rows=sh.getLastRow()>1?sh.getRange(2,3,sh.getLastRow()-1,1).getValues():[];
    const counts={};let total=0;
    rows.forEach(row=>{const name=String(row[0]||'');if(name){counts[name]=(counts[name]||0)+1;total++}});
    response={ok:true,total,counts};
  }catch(err){response={ok:false,error:err.message}}
  const json=JSON.stringify(response);
  // Restrict JSONP callback to a valid simple JavaScript identifier.
  if(!/^[A-Za-z_$][\w$]{0,99}$/.test(callback))return ContentService.createTextOutput(json).setMimeType(ContentService.MimeType.JSON);
  return ContentService.createTextOutput(callback+'('+json+');').setMimeType(ContentService.MimeType.JAVASCRIPT);
}
